# Frontend Audit

## Pages

| Page | Route | Role Access | API Calls | Static/Fake Data? | Works? | Missing Backend? | UX Issues |
|---|---|---|---|---|---|---|---|
| `Home.jsx` | `/` | public | limited/none | mostly real content | yes | no | needs final visual polish |
| `Login.jsx` | `/login` | public | `/api/auth/login` | no | yes | no | standard form flow |
| `Register.jsx` | `/register` | public | signup flow | no | likely yes | no | ensure complete signup contract stays aligned |
| `ForgotPassword.jsx` | `/forgot-password` | public | none or minimal | mostly UI | partial | yes/unknown | likely placeholder flow |
| `ResetPassword.jsx` | `/reset-password` | public | none or minimal | mostly UI | partial | yes/unknown | likely placeholder flow |
| `AdminDashboard.jsx` | `/admin` | admin | `/api/routes`, `/api/fpos`, `/api/farms`, FPO/farm lists | mostly real | yes | admin overview/service-health not proven | route inventory is only partial health truth |
| `FpoDashboard.jsx` | `/fpo/me`, `/fpo/:fpoId` | FPO | FPO, farm, analytics calls | mostly real | likely yes | maybe summary/detail parity | needs backend summary verification |
| `MyFpo.jsx` | `/my-fpo` | FPO | FPO calls | mostly real | likely yes | maybe summary/detail parity | small |
| `FarmerProfile.jsx` | `/farmer/me`, `/farmers/:farmerId` | farmer | farmer + analytics calls | mostly real | likely yes | maybe documents/me details | profile/document actions need contract check |
| `FarmRegister.jsx` | `/farm-register` | protected | location, H3 preview, farm register, hot-stream | mostly real with fallback text | partial | snapshot endpoint missing | contains debug logs and placeholder snapshot language |
| `LandIntelligence.jsx` | `/land/:farmId` | protected | farm, analytics, hot-stream actions | mostly real | likely yes | no major gap proven | very dense UI, but functional |
| `BulkUpload.jsx` | `/bulk-upload` | protected | bulk upload endpoint | likely placeholder-heavy | partial | backend bulk upload route not proven | likely incomplete |
| `Notifications.jsx` | `/notifications` | protected | notification data path not proven | likely static or partial | partial | backend alert path not proven | likely placeholder state |
| `Settings.jsx` | `/settings` | protected | farmer/FPO profile update/export | mostly real | partial | backend export/update parity needs verification | mixed profile editing UX |

## Components

- `FarmPointerMap`: used in admin/FPO views for farm pointer rendering
- `LandGridMap`: used in land intelligence; key visualization component
- `FarmMapView`: present and likely shared map wrapper
- `FarmerLandMap`: present and likely profile map wrapper
- `DistrictMap`: present and likely location visualization
- `FarmCard`: used in registration success flow
- `PipelineGlassLoader`: used in registration and analysis flows

## Frontend truth check

- API calls are routed through the gateway client, which is correct.
- The frontend still contains a few endpoint references that do not have confirmed backend support.
- The land intelligence screen is the strongest example of a real, multi-endpoint page.
- Registration is mostly real, but it still has a couple of fallback/explanation paths that should be cleaned before demo.

