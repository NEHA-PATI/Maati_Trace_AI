import { createBrowserRouter, Navigate } from "react-router-dom";

import ProtectedRoute from "@/features/auth/components/ProtectedRoute";
import AcceptInvitationPage from "@/features/auth/pages/AcceptInvitationPage";
import ForgotPasswordPage from "@/features/auth/pages/ForgotPasswordPage";
import LoginPage from "@/features/auth/pages/LoginPage";
import RegisterPage from "@/features/auth/pages/RegisterPage";
import ResetPasswordPage from "@/features/auth/pages/ResetPasswordPage";
import FpoAccessRequestPage from "@/features/fpo-access/pages/FpoAccessRequestPage";
import FpoAccessAdminPage from "@/features/fpo-access/pages/FpoAccessAdminPage";
import {
  CropStagePage,
  MyCropsPage,
  ObservationHistoryPage,
} from "@/features/crop-observation";
import {
  CropConfigurationEditorPage,
  CropConfigurationPage,
  FarmerObservationMonitorPage,
} from "@/features/crop-observation-admin";
import { PlansPage } from "@/features/plans";
import { ProfileSettingsPage } from "@/features/profile";

import AdminDashboard from "@/pages/AdminDashboard";
import SystemManagementPage from "@/pages/SystemManagementPage";
import BulkUpload from "@/pages/BulkUpload";
import FarmRegister from "@/pages/FarmRegister";
import FarmerProfile from "@/pages/FarmerProfile";
import FpoDashboard from "@/pages/FpoDashboard";
import Home from "@/pages/Home";
import LandIntelligence from "@/pages/LandIntelligence";
import MyFpo from "@/pages/MyFpo";
import Notifications from "@/pages/Notifications";
import OurMethod from "@/pages/OurMethod";
import UseCases from "@/pages/UseCases";

export const router = createBrowserRouter([
  { path: "/", element: <Home /> },
  { path: "/login", element: <LoginPage /> },
  { path: "/register", element: <RegisterPage /> },
  { path: "/forgot-password", element: <ForgotPasswordPage /> },
  { path: "/reset-password", element: <ResetPasswordPage /> },
  { path: "/accept-invitation", element: <AcceptInvitationPage /> },
  { path: "/request-fpo-access", element: <FpoAccessRequestPage /> },
  { path: "/use-cases", element: <UseCases /> },
  { path: "/our-method", element: <OurMethod /> },
  { path: "/plans", element: <PlansPage /> },

  { element: <ProtectedRoute permission="adminDashboard" />, children: [
    { path: "/admin", element: <AdminDashboard /> },
    { path: "/admin/fpo-access", element: <FpoAccessAdminPage /> },
    { path: "/admin/system", element: <SystemManagementPage /> },
    { path: "/admin/feature-processing", element: <SystemManagementPage /> },
  ] },
  {
    element: <ProtectedRoute permission="cropObservationAdmin" />,
    children: [
      { path: "/admin/crop-observations", element: <FarmerObservationMonitorPage /> },
      { path: "/admin/crop-observations/config", element: <CropConfigurationPage /> },
      { path: "/admin/crop-observations/config/:cropCode", element: <CropConfigurationEditorPage /> },
    ],
  },
  { element: <ProtectedRoute permission="fpoDashboard" />, children: [{ path: "/fpo/me", element: <FpoDashboard /> }] },
  { element: <ProtectedRoute permission="myFpo" />, children: [{ path: "/my-fpo", element: <MyFpo /> }] },
  {
    element: <ProtectedRoute permission="farmerProfile" />,
    children: [
      { path: "/farmer/me", element: <FarmerProfile /> },
      { path: "/farmers/:farmerId", element: <FarmerProfile /> },
    ],
  },
  { element: <ProtectedRoute permission="landIntelligence" />, children: [{ path: "/land/:farmId", element: <LandIntelligence /> }] },
  {
    element: <ProtectedRoute permission="cropDiary" />,
    children: [
      { path: "/my-crops", element: <MyCropsPage /> },
      { path: "/my-crops/:farmId/:cropCycleId/history", element: <ObservationHistoryPage /> },
      { path: "/my-crops/:farmId/:cropCycleId/:stageCode", element: <CropStagePage /> },
    ],
  },
  { element: <ProtectedRoute permission="farmRegister" />, children: [{ path: "/farm-register", element: <FarmRegister /> }] },
  { element: <ProtectedRoute permission="bulkUpload" />, children: [{ path: "/bulk-upload", element: <BulkUpload /> }] },
  { element: <ProtectedRoute permission="notifications" />, children: [{ path: "/notifications", element: <Notifications /> }] },
  { element: <ProtectedRoute permission="settings" />, children: [{ path: "/settings", element: <ProfileSettingsPage /> }] },
  { path: "*", element: <Navigate to="/" replace /> },
]);
